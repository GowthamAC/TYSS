package PatternPrograms;

public class Pattern1 {

	public static void main(String[] args) {
		int m=5;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}
