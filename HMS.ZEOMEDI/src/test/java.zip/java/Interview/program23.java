package Interview;

public class program23 {
public static void main(String[] args) {
	
 
}
}
