package Interview;

public class program18 {
public static void main(String[] args) {
	String s="gowtham";  //owthamg
	for (int i = 1; i < s.length(); i++) {
		char ch = s.charAt(i);
		System.out.print(ch);
	}
	System.out.print(s.charAt(0));
}
}
