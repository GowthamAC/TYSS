package Interview;

public class program11 {
public static void main(String[] args) {
	//print all the number divisible by 2
	for (int i = 1; i <=20; i++) {
		if (i%2==0) {
			System.out.print(i+" ");
		}
	}
}
}
