package Interview;

public class program10 {
public static void main(String[] args) {
	//try and catch finally explain
	int a=10;
	int b=0;
	try {
		int c=a%b;
	}catch(Exception e) {
		System.out.println("agalla-----");
	}
	finally {
		System.out.println("execute agutte");
	}
}
}
