package Interview;

import java.util.Iterator;

public class program17 {
public static void main(String[] args) {
	
}
}
