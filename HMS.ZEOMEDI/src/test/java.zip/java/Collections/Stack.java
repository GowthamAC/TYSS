package Collections;

public class Stack {

	public static void main(String[] args) {
	java.util.Stack<Object> s=new java.util.Stack<Object>();
	s.push(10);
	s.push(20);
	System.out.println(s.pop());
	System.out.println(s.pop());
	}

}
