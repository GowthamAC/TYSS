package Collections;

public class TreeSet {

	public static void main(String[] args) {
	java.util.TreeSet<Object> ts=new java.util.TreeSet<Object>();
	ts.add(10);
	ts.add(50);
	ts.add(20);
	ts.add(70);
	// sort in ascending order
	System.out.println(ts);
    
	} 
}
