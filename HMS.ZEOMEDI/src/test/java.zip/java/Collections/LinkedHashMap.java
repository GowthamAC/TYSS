package Collections;

public class LinkedHashMap {

	public static void main(String[] args) {
//		java.util.LinkedHashMap<K, V>

	}

}
